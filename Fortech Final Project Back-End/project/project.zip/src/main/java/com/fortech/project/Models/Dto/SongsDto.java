package com.fortech.project.Models.Dto;

import com.fortech.project.Models.Entity.Songs;

import java.io.Serializable;

public class SongsDto implements Serializable {
    private Long songId;
    private String songName;
    private String genre;
    private String songPicture;
    //private Long albumId;

    public SongsDto(Songs songs) {
        this.songId = songs.getSongId();
        this.songName = songs.getSongName();
        this.genre = songs.getGenre();
        //this.albumId = songs.getAlbums().getAlbumId();
    }

    public SongsDto() {
    }


    public Long getSongId() {
        return songId;
    }

    public void setSongId(Long songId) {
        this.songId = songId;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getSongPicture() {
        return songPicture;
    }

    public void setSongPicture(String songPicture) {
        this.songPicture = songPicture;
    }

}
