package com.fortech.project.Models.Entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="Artists")

public class Artists implements Serializable {
    //Fields
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int artistId;

    @Column(name = "ArtistName")
    private String artistName;

    @Column(name = "ArtistCountry")
    private String artistCountry;

    @Column(name = "ArtistPhoto")
    private String artistPhoto;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "artists_artist_id")
    private List<Albums> albums = new ArrayList<>();

    //Constructors
    public Artists() {
    }
    public Artists(String name, String country,String artistPhoto) {
        setArtistsName(name);
        setArtistsCountry(country);
        setArtistPhoto(artistPhoto);
        setArtistId(0);
    }

    //Getters and Setters
    public List<Albums> getAlbums(){
        return this.albums;
    }
    public void setAlbums(List<Albums> albums) {
        this.albums = albums;
    }

    public void setArtistsCountry(String artistCountry) {
        this.artistCountry = artistCountry;
    }
    public String getArtistsCountry() {
        return artistCountry;
    }

    public void setArtistsName (String artistName) {
        this.artistName = artistName;
    }
    public String getArtistsName() {
        return this.artistName;
    }

    public void setArtistPhoto (String artistPhoto) {
        this.artistPhoto = artistPhoto;
    }
    public String getArtistPhoto() {
        return this.artistPhoto;
    }

    public int getArtistId() {
        return artistId;
    }
    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }
}
