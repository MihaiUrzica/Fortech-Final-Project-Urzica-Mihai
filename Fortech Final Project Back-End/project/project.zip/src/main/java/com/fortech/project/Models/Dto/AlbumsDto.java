package com.fortech.project.Models.Dto;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;


import com.fortech.project.Models.Entity.Albums;
import com.fortech.project.Models.Entity.Artists;

public class AlbumsDto implements Serializable {
    private Long albumId;
    private String albumName;
    private String albumPicture;
    private int artistId;
    private List<SongsDto> albumSongs;

    public AlbumsDto(String albumName, String albumPicture, int artistId) {
        this.albumName = albumName;
        this.albumPicture = albumPicture;
        this.artistId = artistId;
    }
/*
    public AlbumsDto(Albums albums) {
        this.albumId = albums.getAlbumId();
        this.albumName = albums.getAlbumName();
        this.albumPicture = albums.getAlbumPicture();
        this.artistId = albums.getArtists().getArtistId();
        this.albumSongs = albums.getSongs().stream().map(song -> new SongsDto(song)).collect(Collectors.toList());
    }


 */
    public AlbumsDto() {

    }

    public AlbumsDto(Long albumId, String albumName, String albumPicture, int artistId, List<SongsDto> albumSongs) {
        this.albumId = albumId;
        this.albumName = albumName;
        this.albumPicture = albumPicture;
        this.artistId = artistId;
        this.albumSongs = albumSongs;
    }



    public int getArtistId() {
        return this.artistId;
    }
    public void setArtistId(Artists artist) {
        this.artistId = artistId;
    }



    public Long getAlbumId() {
        return albumId;
    }
    public void setAlbumId(Long albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }
    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumPicture() {
        return albumPicture;
    }
    public void setAlbumPicture(String albumPicture) {
        this.albumPicture = albumPicture;
    }

}
