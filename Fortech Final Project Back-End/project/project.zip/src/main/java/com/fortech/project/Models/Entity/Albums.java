package com.fortech.project.Models.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Albums")

public class Albums implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long albumId;

    @Column(name = "AlbumName")
    private String albumName;

    @Column(name = "AlbumPicture")
    private String albumPicture;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "albums_album_id")
    private List<Songs> songs = new ArrayList<>();

    private Artists artists;

    //Constructors
    public Albums(String albumName, String albumPicture) {
        setAlbumName(albumName);
        setAlbumPicture(albumPicture);
        setAlbumId(0L);
    }
    public Albums() {

    }

    //Getters and Setters
    public Long getAlbumId() {
        return this.albumId;
    }
    public void setAlbumId(Long albumId) {
        this.albumId = albumId;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }
    public String getAlbumName() {
        return this.albumName;
    }

    public void setAlbumPicture(String albumPicture) {
        this.albumPicture = albumPicture;
    }
    public String getAlbumPicture() {
        return this.albumPicture;
    }

    public List<Songs> getSongs() {
        return songs;
    }
    public void setSongs(List<Songs> songs) {
        this.songs = songs;
    }


    public void setArtists(Artists artists) {
        this.artists = artists;
    }
    public Artists getArtists(){
        return artists;
    }


}
