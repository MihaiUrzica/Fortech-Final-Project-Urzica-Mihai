package com.fortech.project.Controllers;

import com.fortech.project.Models.Dto.SongsDto;
import com.fortech.project.Models.Entity.Albums;
import com.fortech.project.Repositories.AlbumsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fortech.project.Models.Entity.Songs;
import com.fortech.project.Repositories.SongsRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")

public class SongsController {

    @Autowired
    SongsRepository songsRepository;

    @Autowired
    AlbumsRepository albumsRepository;

    @GetMapping("/songs")
    public ResponseEntity<List<Songs>> getAllSongs(@RequestParam(required = false) String songName) {
        try {
            List<Songs> songs = new ArrayList<Songs>();

            if (songName == null)
                songsRepository.findAll().forEach(songs::add);
            else
                songsRepository.findSongBySongName(songName).forEach(songs::add);
            if (songs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(songs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/songs/{id}")
    public ResponseEntity<Songs> getSongsById(@PathVariable("songId") long songId) {
        Optional<Songs> songsData = songsRepository.findById(songId);

        if (songsData.isPresent()) {
            return new ResponseEntity<>(songsData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/songs")
    public ResponseEntity<Songs> createSongs(@RequestBody SongsDto songs) {
        try {
            //Optional<Albums> optionalAlbums = albumsRepository.findById(songs.getSongId());
            Songs newSong = new Songs(songs.getSongName(), songs.getGenre(), songs.getSongPicture());
            /*if (optionalAlbums.isPresent()) {
                newSong.setAlbums(optionalAlbums.get());
            }

             */
            Songs _songs = songsRepository
                    .save(newSong);
            return new ResponseEntity<>(_songs, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/songs/{id}")
    public ResponseEntity<Songs> updateSongs(@PathVariable("songId") long songId, @RequestBody Songs songs) {
        Optional<Songs> songsData = songsRepository.findById(songId);

        if (songsData.isPresent()) {
            Songs _songs = songsData.get();
            _songs.setSongName(songs.getSongName());
            _songs.setGenre(songs.getGenre());
            _songs.setSongPicture(songs.getSongPicture());
            return new ResponseEntity<>(songsRepository.save(_songs), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/songs/{id}")
    public ResponseEntity<HttpStatus> deleteSongs(@PathVariable("songId") long songId) {
        try {
            songsRepository.deleteById(songId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/songs/ArtistName/{artistName}")
    public ResponseEntity<List<Songs>> findSongByArtistName(@PathVariable("artistName") String artistName) {
        try {
            List<Songs> songs = songsRepository.findSongByArtistName(artistName);

            if (songs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(songs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/songs/AlbumName/{albumName}")
    public ResponseEntity<List<Songs>> findSongByAlbumName(@PathVariable("albumName") String albumName) {
        try {
            List<Songs> songs = songsRepository.findSongByAlbumName(albumName);

            if (songs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(songs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/songs/Genre/{genre}")
    public ResponseEntity<List<Songs>> findSongByGenre(@PathVariable("genre") String genre) {
        try {
            List<Songs> songs = songsRepository.findSongByGenre(genre);

            if (songs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(songs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
