package com.fortech.project.Repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fortech.project.Models.Entity.Albums;
import org.springframework.data.jpa.repository.Query;

public interface AlbumsRepository extends JpaRepository<Albums, Long>{
    //@Query("SELECT a FROM Albums a")
    List<Albums> findAlbumByAlbumName(String albumName);
    //@Query("SELECT a FROM Albums a")
    //List<Albums> findAlbumByArtistName(String artistName);
}
