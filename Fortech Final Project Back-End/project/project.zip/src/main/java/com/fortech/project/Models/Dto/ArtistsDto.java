package com.fortech.project.Models.Dto;
import com.fortech.project.Models.Entity.Albums;
import com.fortech.project.Models.Entity.Artists;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class ArtistsDto implements Serializable {

    public ArtistsDto(int artistId, String artistName, String artistCountry, String artistPhoto) {
        this.artistId = artistId;
        this.artistName = artistName;
        this.artistCountry = artistCountry;
        this.artistPhoto = artistPhoto;
    }



    public ArtistsDto(int artistId, String artistName, String artistCountry, String artistPhoto, Long albumId, List<AlbumsDto> artistAlbums) {
        this.artistId = artistId;
        this.artistName = artistName;
        this.artistCountry = artistCountry;
        this.artistPhoto = artistPhoto;
        this.albumId = albumId;
        this.artistAlbums = artistAlbums;
    }

    private int artistId;
    private String artistName;
    private String artistCountry;
    private String artistPhoto;
    private Long albumId;
    private List<AlbumsDto> artistAlbums;

    //Constructors
    public ArtistsDto(Artists artist) {
        this.artistId = artist.getArtistId();
        this.artistName = artist.getArtistsName();
        this.artistCountry = artist.getArtistsCountry();
        this.artistPhoto = artist.getArtistPhoto();
        //this.albumId = artist.getAlbums().getAlbumId();
        //this.artistAlbums = artist.getAlbums().stream().map(album -> new AlbumsDto(album)).collect(Collectors.toList());
    }
    public ArtistsDto() {

    }

    //Getters and Setters
    public long getArtistId() {
        return artistId;
    }
    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }

    public String getArtistName() {
        return artistName;
    }
    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public String getArtistCountry() {
        return artistCountry;
    }
    public void setArtistCountry(String artistCountry) {
        this.artistCountry = artistCountry;
    }

    public String getArtistPhoto() {
        return artistPhoto;
    }
    public void setArtistPhoto(String artistPhoto) {
        this.artistPhoto = artistPhoto;
    }

}
