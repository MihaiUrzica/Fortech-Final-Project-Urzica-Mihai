package com.fortech.project.Controllers;

import com.fortech.project.Models.Dto.AlbumsDto;
import com.fortech.project.Models.Entity.Artists;
import com.fortech.project.Repositories.ArtistsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fortech.project.Models.Entity.Albums;
import com.fortech.project.Repositories.AlbumsRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")

public class AlbumsController {

    @Autowired
    AlbumsRepository albumsRepository;

    @Autowired
    ArtistsRepository artistsRepository;

    @GetMapping("/albums")
    public ResponseEntity<List<Albums>> getAllAlbums(@RequestParam(required = false) String albumName) {
        try {
            List<Albums> albums = new ArrayList<Albums>();

            if (albumName == null)
                albumsRepository.findAll().forEach(albums::add);
            else
                albumsRepository.findAlbumByAlbumName(albumName).forEach(albums::add);
            if (albums.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(albums, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/albums/{albumId}")
    public ResponseEntity<Albums> getAlbumsById(@PathVariable("albumId") long albumId) {
        Optional<Albums> albumsData = albumsRepository.findById(albumId);

        if (albumsData.isPresent()) {
            return new ResponseEntity<>(albumsData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/albums")
    public ResponseEntity<Albums> createAlbums(@RequestBody AlbumsDto albums) {
        try {
            Optional<Artists>  optionalArtists = artistsRepository.findById((Long.parseLong(""+albums.getArtistId())));
            Albums newAlbum = new Albums(albums.getAlbumName(), albums.getAlbumPicture());
             if(optionalArtists.isPresent()){
                newAlbum.setArtists(optionalArtists.get());
            }

            Albums _albums = albumsRepository
                    .save(newAlbum);
            return new ResponseEntity<>(_albums, HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/albums/{albumId}")
    public ResponseEntity<Albums> updateAlbums(@PathVariable("albumId") long albumId, @RequestBody Albums albums) {
        Optional<Albums> albumsData = albumsRepository.findById(albumId);

        if (albumsData.isPresent()) {
            Albums _albums = albumsData.get();
            _albums.setAlbumName(albums.getAlbumName());
            _albums.setAlbumPicture(albums.getAlbumPicture());
            return new ResponseEntity<>(albumsRepository.save(_albums), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/albums/{albumId}")
    public ResponseEntity<HttpStatus> deleteAlbums(@PathVariable("albumId") long albumId) {
        try {
            albumsRepository.deleteById(albumId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    /*
    @GetMapping("/albums/artist/{artistName}")
    public ResponseEntity<List<Albums>> findAlbumByArtistName(@PathVariable("artistName") String artistName) {
        try {
            List<Artists> artists = artistsRepository.findArtistByName(artistName);
            List<Albums> albums = albumsRepository.findAlbumByArtistName(artistName);

            if (albums.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(albums, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

     */
}
