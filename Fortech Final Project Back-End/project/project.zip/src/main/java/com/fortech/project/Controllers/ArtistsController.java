package com.fortech.project.Controllers;

import com.fortech.project.Models.Dto.ArtistsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fortech.project.Models.Entity.Artists;
import com.fortech.project.Repositories.ArtistsRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")

public class ArtistsController {
    @Autowired
    ArtistsRepository artistsRepository;

    @GetMapping("/artists")
    public ResponseEntity<List<Artists>> getAllArtists(@RequestParam(required = false) String ArtistName) {
        try {
            List<Artists> artists = new ArrayList<Artists>();

            if (ArtistName == null)
                artistsRepository.findAll().forEach(artists::add);
            else
                artistsRepository.findArtistByName(ArtistName).forEach(artists::add);
            if (artists.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(artists, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/artists/{artistId}")
    public ResponseEntity<Artists> getArtistsById(@PathVariable("artistId") long artistId) {
        Optional<Artists> artistsData = artistsRepository.findById(artistId);

        if (artistsData.isPresent()) {
            return new ResponseEntity<>(artistsData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/artists")
    public ResponseEntity<Artists> createArtists(@RequestBody ArtistsDto artists) {
        try {
            Artists newArtist = new Artists(artists.getArtistName(),artists.getArtistCountry(), artists.getArtistPhoto());
            Artists _artists = artistsRepository
                    .save(newArtist);
            return new ResponseEntity<>(_artists, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/artists/{artistId}")
    public ResponseEntity<Artists> updateArtists(@PathVariable("artistId") long artistId, @RequestBody Artists artists) {
        Optional<Artists> artistsData = artistsRepository.findById(artistId);

        if (artistsData.isPresent()) {
            Artists _artists = artistsData.get();
            _artists.setArtistsName(artists.getArtistsName());
            _artists.setArtistsCountry(artists.getArtistsCountry());
            _artists.setArtistPhoto(artists.getArtistPhoto());
            return new ResponseEntity<>(artistsRepository.save(_artists), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/artists/{artistId}")
    public ResponseEntity<HttpStatus> deleteArtists(@PathVariable("artistId") long artistId) {
        try {
            artistsRepository.deleteById(artistId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/artists/{Country}")
    public ResponseEntity<List<Artists>> findArtistByCountry(@PathVariable("Country") String Country) {
        try {
            List<Artists> artists = artistsRepository.findArtistByCountry(Country);

            if (artists.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(artists, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
