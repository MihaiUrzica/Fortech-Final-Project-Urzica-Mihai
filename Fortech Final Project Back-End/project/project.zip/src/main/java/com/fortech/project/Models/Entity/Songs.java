package com.fortech.project.Models.Entity;
import com.fortech.project.Models.Entity.Albums;
import com.fortech.project.Models.Entity.Artists;
import com.fortech.project.Models.Entity.Playlists;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Songs")

public class Songs implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long songId;

    @Column(name = "SongName")
    private String songName;

    @Column(name = "Genre")
    private String genre;

    @Column(name = "SongPicture")
    private String songPicture;

    @ManyToMany
    private List<Playlists> playlists = new ArrayList<>();

    //Constructors
    public Songs(String songName, String genre, String songPicture) {
        setSongId(0L);
        setSongName(songName);
        setGenre(genre);
        setSongPicture(songPicture);
    }
    public Songs() {
    }

    //Getters and Setters
    public void setSongId(Long songId) {
        this.songId = songId;
    }
    public Long getSongId() {
        return songId;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }
    public String getSongName() {
        return this.songName;
    }

    public void setSongPicture(String songPicture) {
        this.songPicture = songPicture;
    }
    public String getSongPicture() {
        return this.songPicture;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    public String getGenre() {
        return this.genre;
    }

}
